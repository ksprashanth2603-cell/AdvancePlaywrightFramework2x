import { test, expect } from '@playwright/test';
import dotenv from 'dotenv';
import { LoginPage } from '@pages/LoginPage';

// Load .env values for this file only.
dotenv.config({ quiet: true, override: true });

test.describe('Checkout with env-based credentials', () => {
    test('logs in using values from .env', async ({ page }) => {
        const username = process.env.USERNAME;
        const password = process.env.PASSWORD;

        if (!username || !password) {
            throw new Error('Missing env vars: set USERNAME and PASSWORD in the project .env file.');
        }

        const loginPage = new LoginPage(page);

        await loginPage.open();
        await loginPage.loginAs(username, password);
        await loginPage.waitForLoginButtonHidden();

        await expect(page).toHaveURL(/\/inventory(?:\.html)?(?:\?|$)/);
    });
});
